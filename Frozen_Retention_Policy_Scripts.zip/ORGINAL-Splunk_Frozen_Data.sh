#!/bin/bash

# Do not output STDERR messages
exec 2>/dev/null

# Set the value for the frozen path
FROZEN_PATH="/frozen"

# Capture the current timestamp for use when outputting events
CURR_DATE="`date +%Y/%m/%dT%T`"

# Log file path
LOG_FILE="/var/log/Splunk_Frozen_Data.log"

# Redirect output to log file and overwrite it
exec > $LOG_FILE

# Iterate through each index in the frozen path. The "_dir" variable is used to store all the paths
for _dir in "$FROZEN_PATH"/*/
do
    # Extract the portion of the path with the index name and store for later use
    CURR_IDX=$(echo $_dir | perl -pe 's/\/frozen\/([^\/]*)\//\1/')

    # Use the "du" command to get the size of the directory. Only the "total" line is used and is then transformed to include a field name "frozen_size_mb"
    FROZEN_SIZE_MB=$(du -cms "$_dir"/ | grep 'total' | perl -pe 's/(\d+)\stotal/frozen_size_mb=\1/')

    # Get the earliest and latest creation times of files in the directory
    EARLIEST_LOG_DATE=$(find "$_dir" -type f -printf '%TY-%Tm-%Td\n' | sort | head -1)
    LATEST_LOG_DATE=$(find "$_dir" -type f -printf '%TY-%Tm-%Td\n' | sort | tail -1)

    # Calculate the difference in days between the earliest and latest log dates
    DAYS_WITH_LOGS=$(( ( $(date -d "$LATEST_LOG_DATE" +%s) - $(date -d "$EARLIEST_LOG_DATE" +%s) ) / (60*60*24) ))

    # Output the data into a Splunk-friendly event format, which includes:
    # 1. A timestamp at the beginning of the event
    # 2. A delimited set of key-value pairs

    echo $CURR_DATE,index_name="$CURR_IDX","$FROZEN_SIZE_MB",days_with_logs="$DAYS_WITH_LOGS",earliest_log_date="$EARLIEST_LOG_DATE",latest_log_date="$LATEST_LOG_DATE"
done

# Get the total size of the frozen path. This is optional since the events produced above can be aggregated to produce a total amount
FROZEN_TOTAL_SIZE=$(du -cms "$FROZEN_PATH"/ | grep 'total' | perl -pe 's/(\d+)\stotal/frozen_size_mb=\1/')

# Output the data. Set "index_name" to "all" since this is for the entire path.
echo $CURR_DATE,index_name=all,"$FROZEN_TOTAL_SIZE"




















#!/bin/bash

# Do not output STDERR messages
exec 2>/dev/null

# Set the value for the frozen path
FROZEN_PATH="/frozen"

# Capture the current timestamp for use when outputting events
CURR_DATE="`date +%Y/%m/%dT%T`"

# Log file path
LOG_FILE="/var/log/Splunk_Frozen_Data.log"

# Configuration file path
CONFIG_FILE="index_size.conf"

# Read the configuration file and store the size limits in an associative array
declare -A INDEX_SIZE_LIMITS
while IFS=, read -r key value
do
    index=$(echo $key | awk -F= '{print $2}')
    size=$(echo $value | awk -F= '{print $2}')
    INDEX_SIZE_LIMITS[$index]=$size
done < $CONFIG_FILE

# Redirect output to log file and overwrite it
exec > $LOG_FILE

# Iterate through each index in the frozen path. The "_dir" variable is used to store all the paths
for _dir in "$FROZEN_PATH"/*/
do
    # Extract the portion of the path with the index name and store for later use
    CURR_IDX=$(echo $_dir | perl -pe 's/\/frozen\/([^\/]*)\//\1/')

    # Use the "du" command to get the size of the directory in MB. Only the "total" line is used and is then transformed to include a field name "frozen_size_mb"
    FROZEN_SIZE_MB=$(du -cms "$_dir"/ | grep 'total' | awk '{print $1}')

    # Get the earliest and latest creation times of files in the directory
    EARLIEST_LOG_DATE=$(find "$_dir" -type f -printf '%TY-%Tm-%Td\n' | sort | head -1)
    LATEST_LOG_DATE=$(find "$_dir" -type f -printf '%TY-%Tm-%Td\n' | sort | tail -1)

    # Calculate the difference in days between the earliest and latest log dates
    DAYS_WITH_LOGS=$(( ( $(date -d "$LATEST_LOG_DATE" +%s) - $(date -d "$EARLIEST_LOG_DATE" +%s) ) / (60*60*24) ))

    # Check if the index size exceeds the limit and delete the oldest files if necessary
    if [ ${INDEX_SIZE_LIMITS[$CURR_IDX]} -lt $FROZEN_SIZE_MB ]; then
        echo "$CURR_DATE,index_name=\"$CURR_IDX\",action=\"exceeds_size_limit\",frozen_size_mb=\"$FROZEN_SIZE_MB\",size_limit_mb=\"${INDEX_SIZE_LIMITS[$CURR_IDX]}\""

        while [ ${INDEX_SIZE_LIMITS[$CURR_IDX]} -lt $FROZEN_SIZE_MB ]; do
            OLDEST_FILE=$(find "$_dir" -type f -printf '%T+ %p\n' | sort | head -1 | awk '{print $2}')
            rm "$OLDEST_FILE"
            FROZEN_SIZE_MB=$(du -cms "$_dir"/ | grep 'total' | awk '{print $1}')
        done

        echo "$CURR_DATE,index_name=\"$CURR_IDX\",action=\"files_deleted\",new_frozen_size_mb=\"$FROZEN_SIZE_MB\""
    fi

    # Output the data into a Splunk-friendly event format, which includes:
    # 1. A timestamp at the beginning of the event
    # 2. A delimited set of key-value pairs

    echo $CURR_DATE,index_name="$CURR_IDX",frozen_size_mb="$FROZEN_SIZE_MB",days_with_logs="$DAYS_WITH_LOGS",earliest_log_date="$EARLIEST_LOG_DATE",latest_log_date="$LATEST_LOG_DATE"
done

# Get the total size of the frozen path. This is optional since the events produced above can be aggregated to produce a total amount
FROZEN_TOTAL_SIZE=$(du -cms "$FROZEN_PATH"/ | grep 'total' | perl -pe 's/(\d+)\stotal/frozen_size_mb=\1/')

# Output the data. Set "index_name" to "all" since this is for the entire path.
echo $CURR_DATE,index_name=all,frozen_size_mb="$FROZEN_TOTAL_SIZE"
